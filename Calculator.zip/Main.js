var g=$("#t1")
function num(n)
{
  var p=g.val()
  
  g.val(p + n)
  
  
}

function cal()
{
 var r=eval(g.val())
 g.val(r)
  
  
}

function n()
{
  
 var h= g.val();
 if(h!='')
 {
   g.val(h.slice(0,-1))
 }
}